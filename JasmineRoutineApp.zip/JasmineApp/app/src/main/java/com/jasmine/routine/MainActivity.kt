package com.jasmine.routine

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        val ask = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it[Manifest.permission.RECORD_AUDIO] == true) WakeWordService.send(this)
        }
        ask.launch(perms)
        setContent { MaterialTheme { App() } }
    }
}

private val Pink = Color(0xFFE91E63)
private val Plum = Color(0xFF7B1FA2)
private val bg = Brush.verticalGradient(listOf(Color(0xFFFFF0F6), Color(0xFFF3E5F5)))

@Composable
fun App() {
    val awake by WakeBus.awake.collectAsStateWithLifecycle()
    if (awake) Home() else Standby()
}

@Composable
fun Standby() {
    Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Mic, null, tint = Pink, modifier = Modifier.size(96.dp))
            Spacer(Modifier.height(16.dp))
            Text("Say  “Hey it's Jasmine”", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Plum)
            Text("I'm listening…", color = Color.Gray)
        }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var goal by remember { mutableStateOf(store.goal) }
    var tasks by remember { mutableStateOf(store.loadTasks()) }
    var editing by remember { mutableStateOf(false) }

    // Text-to-speech
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS } }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }
    LaunchedEffect(ttsReady) {
        if (ttsReady) {
            tts.language = Locale("en", "IN")
            tts.speak("Hello Jasmine, don't forget to smile", TextToSpeech.QUEUE_FLUSH, null, "welcome")
        }
    }

    // Voice -> text (pause the wake-word mic while recognizing)
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        WakeWordService.send(ctx, WakeWordService.ACTION_RESUME)
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) {
                tasks = tasks + Task(System.currentTimeMillis(), said.replaceFirstChar { it.uppercase() })
                store.saveTasks(tasks)
            }
        }
    }
    fun recordTask() {
        WakeWordService.send(ctx, WakeWordService.ACTION_PAUSE)
        speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell me your task…")
        })
    }
    fun readAloud() {
        val pending = tasks.filter { !it.done }
        val text = if (pending.isEmpty()) "You have no tasks left. Great job!"
        else "Your goal is $goal. Today's tasks: " + pending.mapIndexed { i, t -> "${i + 1}. ${t.text}" }.joinToString(". ")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tasks")
    }

    Column(Modifier.fillMaxSize().background(bg).statusBarsPadding().padding(20.dp)) {
        // Greeting
        Text("Hello Jasmine 🌸", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Plum)
        Text("Don't forget to smile 😊", fontSize = 16.sp, color = Pink)
        Spacer(Modifier.height(18.dp))

        // Goal card (tap to edit)
        Card(
            Modifier.fillMaxWidth().clickable { editing = true },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(Modifier.background(Brush.horizontalGradient(listOf(Pink, Plum))).padding(20.dp)) {
                Column {
                    Text("MY GOAL", color = Color.White.copy(alpha = .8f), fontSize = 12.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(goal, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Tap to change", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Today's tasks", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Plum)
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tasks.isEmpty()) item { Text("Tap the mic and tell me your tasks.", color = Color.Gray) }
            items(tasks, key = { it.id }) { t ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(t.done, {
                            tasks = tasks.map { x -> if (x.id == t.id) x.copy(done = it) else x }; store.saveTasks(tasks)
                        })
                        Text(
                            t.text, Modifier.weight(1f),
                            color = if (t.done) Color.Gray else Color.Black,
                            textDecoration = if (t.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                        )
                        IconButton({ tasks = tasks.filter { it.id != t.id }; store.saveTasks(tasks) }) {
                            Icon(Icons.Filled.Delete, "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }

        // Bottom bar
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(::recordTask, Modifier.weight(1f).height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(8.dp)); Text("Add by voice")
            }
            Button(::readAloud, Modifier.weight(1f).height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Plum)) {
                Icon(Icons.Filled.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Read aloud")
            }
        }
    }

    if (editing) {
        var draft by remember { mutableStateOf(goal) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("Edit your goal") },
            text = { OutlinedTextField(draft, { draft = it }, singleLine = true) },
            confirmButton = {
                TextButton({ if (draft.isNotBlank()) { goal = draft.trim(); store.goal = goal }; editing = false }) { Text("Save") }
            },
            dismissButton = { TextButton({ editing = false }) { Text("Cancel") } }
        )
    }
}
