# Jasmine Routine - build in the cloud with GitHub (no Android Studio)

1. Get 3 files: jasmine.onnx (train it in the openWakeWord Colab notebook, phrase "hey its jasmine"),
   melspectrogram.onnx, embedding_model.onnx (openWakeWord shared models).
2. Create a free GitHub account -> New repository (Private is fine).
3. Upload everything in this folder to the repo (Add file -> Upload files), the 3 .onnx files going into app/src/main/assets/.
4. Make sure the file .github/workflows/build.yml exists (if not: Add file -> Create new file, name it
   .github/workflows/build.yml and paste the contents of COPY-THIS-build.yml).
5. Open the Actions tab -> "Build APK" -> wait for the green tick -> open the run -> Artifacts -> download JasmineRoutine-apk.
6. Unzip it, copy app-debug.apk to your phone, open it and allow "Install unknown apps".
7. Open the app, allow Microphone + Notifications, then Settings -> Apps -> Jasmine Routine ->
   allow Full-screen notifications and set Battery to Unrestricted.
