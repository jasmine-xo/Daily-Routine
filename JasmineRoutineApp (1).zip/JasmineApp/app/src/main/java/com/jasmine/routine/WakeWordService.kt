package com.jasmine.routine

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.rementia.openwakeword.lib.DetectionMode
import com.rementia.openwakeword.lib.WakeWordEngine
import com.rementia.openwakeword.lib.WakeWordModel
import kotlinx.coroutines.*

/** Listens for "Hey it's Jasmine" in the background (free, on-device, offline) using openWakeWord. */
class WakeWordService : Service() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var engine: WakeWordEngine? = null
    private var collectJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> stopListening()
            ACTION_RESUME -> startListening()
            else -> { goForeground(); startListening() }
        }
        return START_STICKY
    }

    private fun startListening() {
        if (engine != null) return
        try {
            // Tune THRESHOLD: lower = triggers more easily, higher = fewer false triggers.
            val models = listOf(WakeWordModel("Hey it's Jasmine", MODEL_FILE, THRESHOLD))
            val e = WakeWordEngine(
                context = applicationContext,
                models = models,
                detectionMode = DetectionMode.SINGLE_BEST
            )
            engine = e
            e.start()
            collectJob = scope.launch { e.detections.collect { onWake() } }
        } catch (ex: Exception) { ex.printStackTrace() }
    }

    private fun stopListening() {
        collectJob?.cancel(); collectJob = null
        try { engine?.stop(); engine?.release() } catch (_: Exception) {}
        engine = null
    }

    private fun onWake() {
        WakeBus.awake.value = true
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        // Android blocks background activity starts, so use a full-screen notification.
        val pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, WAKE_CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Hello Jasmine 😊")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
        try { startActivity(open) } catch (_: Exception) {}   // works if app is visible
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(SVC_CH, "Listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(WAKE_CH, "Wake", NotificationManager.IMPORTANCE_HIGH))
        val n = NotificationCompat.Builder(this, SVC_CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Waiting for \"Hey it's Jasmine\"")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    override fun onDestroy() { stopListening(); scope.cancel(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"
        private const val MODEL_FILE = "jasmine.onnx"   // your trained model, in app/src/main/assets
        private const val THRESHOLD = 0.5f
        private const val SVC_CH = "svc"
        private const val WAKE_CH = "wake"

        fun send(ctx: Context, action: String? = null) {
            ctx.startForegroundService(Intent(ctx, WakeWordService::class.java).setAction(action))
        }
    }
}
