package com.jasmine.routine

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id: Long, val text: String, val done: Boolean = false)

/** Shared state between the wake-word service and the UI. */
object WakeBus {
    val awake = MutableStateFlow(false)   // false = standby screen, true = home page
}

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("routine", Context.MODE_PRIVATE)

    var goal: String
        get() = prefs.getString("goal", "Become Data Analyst")!!
        set(v) = prefs.edit().putString("goal", v).apply()

    fun loadTasks(): List<Task> {
        val arr = JSONArray(prefs.getString("tasks", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getLong("id"), o.getString("text"), o.getBoolean("done"))
        }
    }

    fun saveTasks(tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done)) }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }

    fun customQuotes(): List<String> {
        val arr = JSONArray(prefs.getString("quotes", "[]"))
        return (0 until arr.length()).map { arr.getString(it) }
    }

    fun addQuote(q: String) {
        val arr = JSONArray()
        (customQuotes() + q).forEach { arr.put(it) }
        prefs.edit().putString("quotes", arr.toString()).apply()
    }
}
